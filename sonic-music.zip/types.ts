export interface ForensicData {
  key: string;
  bpm: string;
  genreTags: string[];
  vocalChain: string; // Hardware/Style description
  instruments: string[];
  studioGear: string[];
  vocalAnalysis: string; // New field for extreme vocal detail
}

export interface AnalysisResult {
  metadata: ForensicData;
  sunoPrompt: string;      // The detailed style prompt ~1000 chars
  lyrics: string;          // Rewritten with rhythmic chops and [meta tags] per line
  negativePrompt: string;  // Exclusion filter ~500 chars
}

export enum AppState {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  COMPLETE = 'COMPLETE',
  ERROR = 'ERROR'
}
