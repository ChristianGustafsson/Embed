import React, { useState } from 'react';
import { AppState, AnalysisResult } from './types';
import { analyzeTrack } from './services/geminiService';
import { ConsoleInput } from './components/ConsoleInput';
import { TerminalLoader } from './components/TerminalLoader';
import { ForensicDashboard } from './components/ForensicDashboard';
import { Disc } from 'lucide-react';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [analysisData, setAnalysisData] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async (artist: string, song: string) => {
    setAppState(AppState.ANALYZING);
    setError(null);
    try {
      const result = await analyzeTrack(artist, song);
      setAnalysisData(result);
      setAppState(AppState.COMPLETE);
    } catch (err: any) {
      console.error(err);
      setError("Satellite handshake failed. Check your data link or artist spelling.");
      setAppState(AppState.ERROR);
    }
  };

  const handleReset = () => {
    setAppState(AppState.IDLE);
    setAnalysisData(null);
    setError(null);
  };

  return (
    <div className="h-[100dvh] w-full flex flex-col bg-slate-950 overflow-hidden relative selection:bg-cyan-500 selection:text-black">
      
      {/* Immersive Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
         <div className="absolute top-[-10%] left-[-10%] w-[120%] h-[60%] bg-blue-900/10 rounded-full blur-[120px]" />
         <div className="absolute bottom-[-10%] right-[-10%] w-[120%] h-[60%] bg-cyan-900/10 rounded-full blur-[120px]" />
      </div>

      {/* App Header (Fixed) */}
      <header className="flex-none z-30 pt-[var(--sat)] bg-slate-950/90 backdrop-blur-xl border-b border-white/5">
        <div className="px-6 py-4 flex justify-between items-center max-w-7xl mx-auto">
          <div className="flex items-center space-x-3">
             <Disc className={`w-6 h-6 text-cyan-400 ${appState === AppState.ANALYZING ? 'animate-spin' : ''}`} />
             <h1 className="text-xl font-orbitron font-black italic tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-white to-cyan-400">
               SONIC <span className="text-cyan-500">ALCHEMIST</span>
             </h1>
          </div>
          <div className="hidden md:flex items-center space-x-4">
            <span className="text-[10px] text-slate-500 font-mono flex items-center">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 mr-2 animate-pulse"></span>
              SYS_ACTIVE
            </span>
          </div>
        </div>
      </header>

      {/* App Main (Scrollable Content) */}
      <main className="flex-1 overflow-y-auto overflow-x-hidden relative z-20 custom-scrollbar overscroll-none flex flex-col items-center">
        <div className="w-full max-w-7xl px-4 py-8 md:py-12 flex-1 flex flex-col items-center">
          
          {appState === AppState.IDLE && (
            <div className="w-full max-w-2xl animate-fade-in-up flex-1 flex flex-col justify-center pb-20">
              <div className="text-center mb-10">
                 <h2 className="text-3xl md:text-5xl font-orbitron font-black text-white mb-4 tracking-tighter uppercase">Forensic Music Lab</h2>
                 <p className="text-slate-400 font-mono text-xs md:text-sm max-w-md mx-auto leading-relaxed">
                   Deconstruct target audio DNA into structural, timbral, and performance data for Suno v5 cloning.
                 </p>
              </div>
              
              <ConsoleInput onAnalyze={handleAnalyze} isLoading={false} />
              
              <div className="mt-12 text-center opacity-40">
                <p className="text-[9px] text-slate-500 uppercase tracking-[0.3em] mb-4">Deep Research Mode Active</p>
              </div>
            </div>
          )}

          {appState === AppState.ANALYZING && (
            <div className="w-full h-full flex items-center justify-center">
              <TerminalLoader />
            </div>
          )}

          {appState === AppState.COMPLETE && analysisData && (
            <ForensicDashboard data={analysisData} onReset={handleReset} />
          )}

          {appState === AppState.ERROR && (
            <div className="flex-1 flex flex-col items-center justify-center py-10">
              <div className="text-center bg-red-950/30 border border-red-500/30 p-8 md:p-12 rounded-3xl max-w-md mx-4 backdrop-blur-md">
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <div className="w-8 h-8 text-red-500">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                  </div>
                </div>
                <h3 className="text-red-400 font-orbitron text-xl mb-3 uppercase tracking-widest">Signal Failure</h3>
                <p className="text-red-200/60 font-mono text-sm mb-8">{error}</p>
                <button 
                  onClick={handleReset}
                  className="w-full bg-red-600 hover:bg-red-500 text-white py-4 rounded-xl font-orbitron font-bold uppercase text-xs tracking-widest transition-all active:scale-95 shadow-lg shadow-red-900/40"
                >
                  Hard Reset
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* App Footer (Fixed) */}
      <footer className="flex-none z-30 pb-[var(--sab)] bg-slate-950/90 backdrop-blur-xl border-t border-white/5">
        <div className="px-6 py-4 flex flex-col md:flex-row justify-between items-center space-y-2 md:space-y-0">
          <p className="text-[10px] text-slate-600 font-mono uppercase tracking-[0.2em]">
            <span className="text-cyan-500/50">Core:</span> Gemini 3 Pro <span className="mx-2">|</span> <span className="text-cyan-500/50">Engine:</span> Suno v5 Forensic
          </p>
          <div className="flex space-x-4 opacity-50">
             <div className="w-2 h-2 rounded-full bg-slate-800"></div>
             <div className="w-2 h-2 rounded-full bg-slate-800"></div>
             <div className="w-2 h-2 rounded-full bg-slate-800"></div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;