import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AnalysisResult } from "../types";

const apiKey = process.env.API_KEY;

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: apiKey });

const analysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    metadata: {
      type: Type.OBJECT,
      properties: {
        key: { type: Type.STRING, description: "Musical key (e.g., C Minor, F# Major)" },
        bpm: { type: Type.STRING, description: "Exact BPM and Time Signature (e.g., 78 BPM, 12/8 Time Signature)" },
        genreTags: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING },
          description: "List of 5-8 specific sub-genres, eras, and vibe tags (e.g. 'Blue-Eyed Soul', '1991 Studio Master')"
        },
        vocalChain: { type: Type.STRING, description: "Technical description of signal chain. Identify hardware used to capture 'breathy' highs, 'nasal' mids, or 'chest resonance' (e.g., Sony C800G for air, Neve 1073 for saturation)." },
        vocalAnalysis: { type: Type.STRING, description: "EXTREME DETAIL: Identify Gender (Male/Female/Androgynous), Voice Type (e.g. Soprano, Tenor, Baritone), and approximate Pitch Range. Explicitly identify 'breathy' textures, 'nasal' placement, 'chest resonance', 'falsetto', and 'vocal fry'. Analyze larynx position, vibrato speed, and unique inflections." },
        instruments: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING },
          description: "List of specific instruments used (e.g., DX7 Piano, Roland TR-808, Gibson Les Paul)"
        },
        studioGear: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "List of likely production gear/effects WITH specific settings or techniques (e.g., 'SSL 4000 E Series Console with aggressive compression', 'Lexicon 224 with long pre-delay')."
        }
      },
      required: ["key", "bpm", "genreTags", "vocalChain", "vocalAnalysis", "instruments", "studioGear"]
    },
    sunoPrompt: {
      type: Type.STRING,
      description: "A massive, comma-separated forensic prompt. MUST start with Era, Genre, Time Sig. Then combine ALL instruments, studio gear, and detailed vocal descriptors. Example: '1991 Studio Master, Blue-Eyed Soul, Power Ballad, 12/8 Time Signature...'"
    },
    lyrics: {
      type: Type.STRING,
      description: "Rewritten lyrics formatted exactly: [Section] -> (Instrumental Layers) -> [Style: Vocal Details] -> Hyphenated-Lyrics."
    },
    negativePrompt: {
      type: Type.STRING,
      description: "~500 characters of negative prompts. Exclude 'AI artifacts', ensure 'lossless' quality."
    }
  },
  required: ["metadata", "sunoPrompt", "lyrics", "negativePrompt"]
};

export const analyzeTrack = async (artist: string, song: string): Promise<AnalysisResult> => {
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }

  const prompt = `
    You are SONIC ALCHEMIST, a forensic music supercomputer analyzing audio for Suno v5 cloning.
    
    Target: "${song}" by "${artist}".
    
    MISSION OBJECTIVES:
    1. **DEEP SEARCH & FORENSICS**: Analyze the track in extreme detail. Identify the exact BPM, Time Signature (e.g. 12/8, 4/4), Key, Studio Equipment (Neve consoles, tape saturation, specific reverbs), and most importantly, the VOCALS.
    
    2. **VOCAL PROFILING**: Analyze the singer's technique. YOU MUST SPECIFY:
       - **GENDER & TYPE**: Male, Female, or Androgynous? Tenor, Baritone, Alto, Soprano?
       - **PITCH & RANGE**: Define the fundamental pitch range used.
       - **TEXTURE**: Rasp, Breath, Fry, Belt, Head Voice, Chest Voice.
       - **CORRECTION PROTOCOL**: If the artist is Female, ensure the prompt DOES NOT describe a "male" or "low" voice. If the artist is a high tenor, ensure "Baritone" is not used.

    3. **OUTPUT REQUIREMENTS**:
    
    --- OUTPUT 1: SUNO V5 STYLE PROMPT (~1000 chars) ---
    - Construct a high-density string combining metadata, gear, and performance.
    - **START WITH**: Year, Era, Production Quality (e.g. "1991 Studio Master"), Genre, Time Signature, Groove.
    - **ADD**: Specific Instruments, Studio Gear (Console, Pre-amps, Compression settings).
    - **ADD**: Detailed Vocal Description (Type, Range, Texture).
    - **EXAMPLE**: "1991 Studio Master, Blue-Eyed Soul, Power Ballad, 12/8 Time Signature, Triplet Feel, Slow Jam, Adult Contemporary, High-Larynx Tenor Belt, Raspy Vocal Texture, Grand Piano, Hammond B3 Organ, Clean Electric Guitar with Chorus, Orchestral Swell, Key Change Modulation, Analog Tube Saturation, Neve Console Warmth..."
    
    --- OUTPUT 2: LYRICS STUDIO (~1000 chars) ---
    - Rewrite lyrics slightly to avoid copyright, but keep exact prosody.
    - **STRICT FORMATTING**:
      [Section Name]
      (Instrumental Layer 1)
      (Instrumental Layer 2)
      [Style: Exact Vocal Texture, Technique, Mic Proximity]
      Ly-rics-with-hy-phens-for-rhy-thm
    
    - **EXAMPLE**:
      [Intro]
      (Clean Stratocaster Arpeggios with Chorus FX)
      (Hammond B3 Organ Swell)
      
      [Verse 1]
      [Style: Intimate Chest Voice, Soft Rasp, Breathy Onset, Close Mic Proximity]
      When the heart rules the spi-rit.
      Can't find a peace in no-thin' else.
      
      [Bridge]
      [Style: High-Larynx Belt, Heavy False Fold Constriction, Pharyngeal Mask Resonance]
      [Dynamic: Fortissimo]
      I burn through ev-ry-thing I hold. (Oh-whoa!)

      [Guitar Solo]
      (Soaring High Gain Lead Guitar - Michael Thompson Style)

    --- OUTPUT 3: NEGATIVE PROMPT (~500 chars) ---
    - List what to avoid to ensure LOSSLESS quality: "AI artifacts, robotic, synthetic, auto-tune, machine-generated, noise, glitch, distorted, compressed, lossy, mp3, low bitrate, mumble, low-fi, mono, muddy mix, wrong gender, wrong voice type."

    Return ONLY the JSON matching the schema.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        thinkingConfig: {
            thinkingBudget: 8192 // Maximum thinking budget for extreme detail
        }
      }
    });

    const resultText = response.text;
    if (!resultText) throw new Error("No response from AI");

    return JSON.parse(resultText) as AnalysisResult;

  } catch (error) {
    console.error("Analysis failed:", error);
    throw error;
  }
};
