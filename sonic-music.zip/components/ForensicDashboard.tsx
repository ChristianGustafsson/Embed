import React from 'react';
import { AnalysisResult } from '../types';
import { Copy, Music, Mic2, Settings, FileText, Share2, ChevronLeft } from 'lucide-react';

interface Props {
  data: AnalysisResult;
  onReset: () => void;
}

const CopyButton: React.FC<{ text: string; label: string; colorClass?: string; widthClass?: string }> = ({ 
  text, 
  label, 
  colorClass = "text-slate-300 border-slate-600 hover:bg-slate-700",
  widthClass = "w-full"
}) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className={`flex items-center justify-center space-x-2 px-4 py-4 rounded-xl text-[10px] font-bold tracking-[0.2em] transition-all uppercase border group active:scale-[0.96] touch-manipulation ${widthClass} ${
        copied 
          ? 'bg-green-500/20 border-green-500 text-green-400' 
          : `bg-slate-900/60 backdrop-blur-md ${colorClass}`
      }`}
    >
      <Copy className={`w-4 h-4 ${copied ? 'text-green-400' : 'group-hover:scale-110 transition-transform'}`} />
      <span>{copied ? 'COPIED' : label}</span>
    </button>
  );
};

export const ForensicDashboard: React.FC<Props> = ({ data, onReset }) => {
  return (
    <div className="w-full animate-fade-in pb-12">
      
      {/* Dynamic Report Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 bg-slate-900/30 p-6 rounded-2xl border border-white/5 backdrop-blur-sm">
        <div>
          <h2 className="text-[10px] text-cyan-500 font-mono uppercase tracking-[0.4em] mb-1">Status: Extraction Complete</h2>
          <h1 className="text-xl md:text-3xl font-orbitron font-black text-white italic tracking-tighter">
            DNA_REPORT_<span className="text-cyan-500">V5.0</span>
          </h1>
        </div>
        <button 
          onClick={onReset}
          className="mt-4 md:mt-0 flex items-center space-x-2 text-[10px] text-slate-400 hover:text-white uppercase tracking-widest transition-all border border-slate-800 hover:border-cyan-500/50 px-5 py-3 rounded-xl bg-slate-900/40 active:scale-95"
        >
          <ChevronLeft className="w-3 h-3" />
          <span>New Target</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8">
        
        {/* Left Column: Forensics */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Key Metrics */}
          <div className="bg-slate-950/40 border border-white/5 rounded-3xl p-6">
            <h3 className="text-[10px] text-cyan-500 font-bold uppercase tracking-[0.2em] mb-5 flex items-center">
              <Settings className="w-3 h-3 mr-2" /> Spectral Telemetry
            </h3>
            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="bg-slate-900/80 p-4 rounded-2xl border border-white/5">
                <div className="text-[9px] text-slate-500 uppercase mb-1">Key</div>
                <div className="text-lg text-white font-bold font-orbitron">{data.metadata.key}</div>
              </div>
              <div className="bg-slate-900/80 p-4 rounded-2xl border border-white/5">
                <div className="text-[9px] text-slate-500 uppercase mb-1">BPM / Sig</div>
                <div className="text-lg text-white font-bold font-orbitron truncate">{data.metadata.bpm}</div>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-2">
               {data.metadata.genreTags.map((tag, i) => (
                 <span key={i} className="text-[9px] bg-cyan-500/10 text-cyan-400 px-3 py-1.5 rounded-full border border-cyan-500/20 font-bold">
                   {tag.toUpperCase()}
                 </span>
               ))}
            </div>
          </div>

          {/* Vocal Profile Detail */}
          <div className="bg-slate-950/40 border border-white/5 rounded-3xl p-6 relative overflow-hidden">
             <div className="absolute top-[-20px] right-[-20px] opacity-5 pointer-events-none">
                <Mic2 className="w-32 h-32 text-blue-500" />
             </div>
             <h3 className="text-[10px] text-blue-400 font-bold uppercase tracking-[0.2em] mb-4 flex items-center">
               <Mic2 className="w-3 h-3 mr-2" /> Vocal Signature
             </h3>
             <div className="space-y-4">
                <div className="text-[11px] text-slate-300 leading-relaxed font-mono p-4 bg-blue-500/5 rounded-2xl border border-blue-500/10">
                  {data.metadata.vocalAnalysis}
                </div>
                <div className="p-4 bg-slate-900/60 rounded-2xl border border-white/5">
                  <span className="block text-slate-600 text-[8px] uppercase tracking-widest mb-2 font-bold">Signal Chain Target</span>
                  <p className="text-[10px] text-slate-400 italic">{data.metadata.vocalChain}</p>
                </div>
             </div>
          </div>
        </div>

        {/* Right Column: Deployment Deck */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* COPY COMMANDS */}
          <div className="bg-slate-900/60 border border-white/10 p-6 rounded-3xl backdrop-blur-xl">
            <div className="flex items-center justify-between mb-6">
               <h2 className="text-xs font-orbitron text-cyan-400 tracking-[0.4em] flex items-center">
                 <Share2 className="w-4 h-4 mr-2" />
                 DEPLOYMENT DECK
               </h2>
               <div className="flex space-x-1.5">
                 <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse"></div>
                 <div className="w-1.5 h-1.5 rounded-full bg-cyan-500/40"></div>
                 <div className="w-1.5 h-1.5 rounded-full bg-cyan-500/10"></div>
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <CopyButton 
                text={data.sunoPrompt} 
                label="STYLE PROMPT" 
                colorClass="text-cyan-400 border-cyan-500/20 hover:bg-cyan-500/10"
              />
              <CopyButton 
                text={data.lyrics} 
                label="DNA LYRICS" 
                colorClass="text-purple-400 border-purple-500/20 hover:bg-purple-500/10"
              />
              <CopyButton 
                text={data.negativePrompt} 
                label="EXCLUSIONS" 
                colorClass="text-red-400 border-red-500/20 hover:bg-red-500/10"
              />
            </div>
          </div>

          {/* PREVIEWS */}
          <div className="grid grid-cols-1 gap-6">
            
            <div className="bg-black/40 rounded-3xl border border-white/5 p-6">
               <div className="text-[10px] text-cyan-600 font-bold uppercase tracking-[0.3em] mb-4">Prompt Preview</div>
               <div className="text-[11px] text-cyan-100/70 font-mono leading-relaxed bg-slate-950/50 p-5 rounded-2xl border border-cyan-500/10">
                 {data.sunoPrompt}
               </div>
            </div>

            <div className="bg-black/40 rounded-3xl border border-white/5 p-6">
               <div className="text-[10px] text-purple-600 font-bold uppercase tracking-[0.3em] mb-4">Lyrics Matrix</div>
               <div className="text-[11px] text-slate-400 font-mono leading-loose whitespace-pre-wrap max-h-[500px] overflow-y-auto custom-scrollbar border-l-2 border-purple-500/30 pl-6 pr-4">
                 {data.lyrics}
               </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};