import React, { useState } from 'react';
import { Search, Zap } from 'lucide-react';

interface Props {
  onAnalyze: (artist: string, song: string) => void;
  isLoading: boolean;
}

export const ConsoleInput: React.FC<Props> = ({ onAnalyze, isLoading }) => {
  const [artist, setArtist] = useState('');
  const [song, setSong] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (artist.trim() && song.trim()) {
      onAnalyze(artist, song);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto bg-slate-900/40 border border-slate-800/60 p-5 md:p-8 rounded-2xl shadow-2xl backdrop-blur-md">
      <form onSubmit={handleSubmit} className="space-y-5">
        
        <div className="space-y-2">
          <label className="text-[9px] md:text-[10px] uppercase tracking-[0.2em] text-cyan-500 font-bold ml-1 block">Target Artist</label>
          <div className="relative group">
            <input
              type="text"
              value={artist}
              onChange={(e) => setArtist(e.target.value)}
              placeholder="e.g. Tommy Nilsson"
              className="w-full bg-slate-950/80 text-white border border-slate-700/50 rounded-xl p-4 pl-11 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/30 transition-all font-mono text-sm"
              disabled={isLoading}
            />
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-600 w-5 h-5 group-focus-within:text-cyan-500 transition-colors" />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[9px] md:text-[10px] uppercase tracking-[0.2em] text-cyan-500 font-bold ml-1 block">Target Song</label>
          <div className="relative group">
             <input
              type="text"
              value={song}
              onChange={(e) => setSong(e.target.value)}
              placeholder="e.g. En Dag"
              className="w-full bg-slate-950/80 text-white border border-slate-700/50 rounded-xl p-4 pl-11 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/30 transition-all font-mono text-sm"
              disabled={isLoading}
            />
            <MusicIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-600 w-5 h-5 group-focus-within:text-cyan-500 transition-colors" />
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading || !artist || !song}
          className={`w-full py-4 rounded-xl font-orbitron tracking-widest font-bold uppercase transition-all flex justify-center items-center gap-2 group active:scale-[0.98] ${
            isLoading || !artist || !song
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              : 'bg-blue-600 hover:bg-cyan-500 text-white border border-blue-400 hover:border-cyan-200 shadow-[0_0_15px_rgba(37,99,235,0.4)] hover:shadow-[0_0_25px_rgba(6,182,212,0.5)]'
          }`}
        >
          {isLoading ? (
             <span className="animate-pulse flex items-center gap-2">
               <span className="w-2 h-2 rounded-full bg-white animate-bounce" />
               UPLINKING...
             </span>
          ) : (
            <>
              <Zap className="w-4 h-4 md:w-5 md:h-5 group-hover:fill-current" />
              <span className="text-sm">Initiate Clone</span>
            </>
          )}
        </button>
      </form>
      
      {/* Decorative Console Text */}
      <div className="mt-6 border-t border-slate-800/60 pt-4 px-1">
        <div className="text-[8px] md:text-[10px] text-slate-600 font-mono flex justify-between uppercase tracking-wider">
          <span>Sys: Ready</span>
          <span>v.5.2-alpha</span>
        </div>
        <div className="text-[8px] text-slate-700 font-mono mt-2 uppercase leading-relaxed text-center opacity-60">
          Forensic extraction active...
        </div>
      </div>
    </div>
  );
};

const MusicIcon = (props: any) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
)