import React, { useEffect, useState } from 'react';
import { Activity, Radio, Cpu, HardDrive } from 'lucide-react';

const LOG_MESSAGES = [
  "Initializing handshake...",
  "Connecting to global database...",
  "Decompiling spectral layers...",
  "Isolating vocal frequencies...",
  "Identifying microphone signature...",
  "Analyzing compression ratio...",
  "Extracting chord topology...",
  "Synthesizing Suno V5 DNA...",
  "Finalizing clone sequence..."
];

export const TerminalLoader: React.FC = () => {
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < LOG_MESSAGES.length) {
        setLogs(prev => [...prev, `> ${LOG_MESSAGES[i]}`]);
        i++;
      } else {
        clearInterval(interval);
      }
    }, 600);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full max-w-4xl mx-auto p-5 md:p-8 border border-cyan-500/30 bg-slate-900/60 rounded-2xl relative overflow-hidden min-h-[450px] md:h-[600px] flex flex-col items-center justify-center font-mono backdrop-blur-xl">
      {/* Scanline Effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/5 to-transparent h-[10%] w-full animate-scan pointer-events-none opacity-20"></div>

      <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4 mb-8 text-center md:text-left">
         <div className="relative">
             <div className="absolute inset-0 bg-cyan-500 blur-xl opacity-40 animate-pulse"></div>
             <Activity className="w-12 h-12 md:w-16 md:h-16 text-cyan-400 animate-pulse-fast relative z-10" />
         </div>
         <h2 className="text-xl md:text-3xl font-orbitron text-cyan-400 tracking-widest neon-text-cyan">
           MASTERING ENGINE
         </h2>
      </div>

      <div className="grid grid-cols-3 gap-4 md:gap-8 w-full max-w-lg mb-8 md:mb-12 opacity-70">
        <div className="flex flex-col items-center text-cyan-700">
           <Radio className="w-6 h-6 md:w-8 md:h-8 animate-spin" style={{ animationDuration: '3s' }} />
           <span className="text-[8px] md:text-xs mt-2 uppercase">Spectral</span>
        </div>
        <div className="flex flex-col items-center text-cyan-700">
           <Cpu className="w-6 h-6 md:w-8 md:h-8 animate-pulse" />
           <span className="text-[8px] md:text-xs mt-2 uppercase">Processing</span>
        </div>
        <div className="flex flex-col items-center text-cyan-700">
           <HardDrive className="w-6 h-6 md:w-8 md:h-8" />
           <span className="text-[8px] md:text-xs mt-2 uppercase">Archiving</span>
        </div>
      </div>

      <div className="w-full max-w-2xl bg-black/40 border border-slate-700/50 p-4 rounded-xl h-40 md:h-48 overflow-y-auto font-mono text-[10px] md:text-sm shadow-inner scroll-smooth">
        {logs.map((log, idx) => (
          <div key={idx} className="text-green-500/80 mb-1 leading-relaxed">{log}</div>
        ))}
        <div className="animate-pulse text-green-500 inline-block ml-1">_</div>
      </div>
      
      <p className="mt-6 text-cyan-600/60 uppercase text-[8px] md:text-xs tracking-[0.3em] animate-pulse text-center px-4">
        DEEP ANALYSIS: Melodic Contour & Prosody Clone...
      </p>
    </div>
  );
};