
import React, { useState } from 'react';
import { DEFAULT_PROFILE, SAMPLE_LYRICS_INPUT } from './constants';
import { SonicProfile, GeneratedPrompt } from './types';
import { searchAndAnalyzeSonicProfile, generateSunoPrompt } from './geminiService';

export default function App() {
  const [profile, setProfile] = useState<SonicProfile>(DEFAULT_PROFILE);
  const [userInput, setUserInput] = useState(SAMPLE_LYRICS_INPUT);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<GeneratedPrompt | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hasPerformedResearch, setHasPerformedResearch] = useState(false);
  const [sources, setSources] = useState<any[]>([]);
  
  const [searchQuery, setSearchQuery] = useState("");
  const [customSetting, setCustomSetting] = useState("Protocol: Lossless Master Grade. BANNED: Adjectives. MANDATORY: Melodic Phrasing (Interval Leaps, Pentatonic bias), Harmonic Series Analysis, and Physiological Performance Auditing (Breathy, Nasal, Chest, Fry). Use thinking budget to lock Melodic Contour and Syllabic Stress against BPM/Key. Ensure absolute melodic precision in final prompt.");
  const [showSettings, setShowSettings] = useState(false);

  const handleResearch = async () => {
    if (!searchQuery.trim()) return;
    setIsAnalyzing(true);
    setError(null);
    setResult(null);
    try {
      const data = await searchAndAnalyzeSonicProfile(searchQuery, customSetting);
      const { sources: s, ...newProfile } = data;
      setProfile(newProfile as SonicProfile);
      setSources(s);
      setHasPerformedResearch(true);
    } catch (err: any) {
      setError("Forensic audit failed. Could not verify melodic DNA or sub-fundamentals.");
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const generated = await generateSunoPrompt(profile, userInput, customSetting);
      setResult(generated);
    } catch (err: any) {
      setError("Score compilation failed. Melodic contour buffer overflow.");
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="min-h-screen pb-20 px-4 md:px-8 lg:px-16 pt-8 bg-[#010204]">
      {/* Header */}
      <header className="mb-12 text-center relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-blue-600/5 blur-[120px] -z-10"></div>
        <h1 className="text-4xl md:text-6xl font-bold font-heading mb-2 tracking-tighter uppercase italic">
          SONIC <span className="text-blue-500">ALCHEMIST</span>
        </h1>
        <div className="flex items-center justify-center gap-4 text-slate-500 max-w-2xl mx-auto text-[10px] font-mono tracking-widest uppercase">
          <span className="flex items-center gap-1 text-blue-400"><i className="fas fa-compact-disc animate-spin-slow"></i> LOSSLESS DNA</span>
          <span className="w-1 h-1 bg-slate-800 rounded-full"></span>
          <span className="flex items-center gap-1 text-emerald-500"><i className="fas fa-wave-square"></i> MELODIC CONTOUR</span>
          <span className="w-1 h-1 bg-slate-800 rounded-full"></span>
          <span className="flex items-center gap-1 text-red-500"><i className="fas fa-lungs"></i> PHYSIO-AUDIT</span>
        </div>
      </header>

      <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Research & Technical Readout */}
        <section className="lg:col-span-4 space-y-6">
          
          {/* Settings Panel Toggle */}
          <div className="glass rounded-2xl border-white/5 bg-black/40 overflow-hidden shadow-2xl">
             <button 
               onClick={() => setShowSettings(!showSettings)}
               className="w-full p-4 flex justify-between items-center text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-white transition-colors border-b border-white/5"
             >
               <span><i className="fas fa-sliders-h mr-2 text-blue-400"></i> MASTERING PARAMETERS</span>
               <i className={`fas fa-chevron-${showSettings ? 'up' : 'down'}`}></i>
             </button>
             {showSettings && (
               <div className="p-4 space-y-3 bg-black/40">
                 <p className="text-[9px] text-slate-600 font-mono leading-relaxed uppercase">Master Engineering Directives:</p>
                 <textarea 
                   value={customSetting}
                   onChange={(e) => setCustomSetting(e.target.value)}
                   className="w-full h-40 bg-black/60 border border-white/10 rounded-lg p-3 text-[10px] font-mono text-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-500/30 leading-relaxed"
                 />
               </div>
             )}
          </div>

          {/* Research Box */}
          <div className="glass rounded-2xl p-6 border-white/5 relative overflow-hidden bg-black/40 border-l-2 border-l-blue-500/50 shadow-2xl">
            <div className="flex items-center gap-2 mb-4">
              <div className={`w-2 h-2 rounded-full ${isAnalyzing ? 'bg-amber-500 animate-pulse' : 'bg-blue-500'}`}></div>
              <label className="text-[10px] uppercase tracking-[0.3em] text-slate-400 font-bold">Lossless Target Audit</label>
            </div>
            <input 
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleResearch()}
              placeholder="Artist, Song, or Melodic ID..."
              className="w-full bg-black/60 border border-white/10 rounded-xl py-4 px-5 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500/50 transition-all font-mono mb-3 text-white placeholder:text-slate-800"
            />
            <button 
              onClick={handleResearch}
              disabled={isAnalyzing || !searchQuery}
              className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-900/20"
            >
              {isAnalyzing ? <><i className="fas fa-atom fa-spin"></i> AUDITING MELODIC DNA...</> : 'INITIATE LOSSLESS AUDIT'}
            </button>
          </div>

          {/* Technical Readout */}
          <div className={`glass rounded-2xl p-6 border-white/5 bg-black/20 ${hasPerformedResearch ? 'border-blue-500/40 ring-1 ring-blue-500/10' : ''}`}>
            <h2 className="text-xs font-bold uppercase tracking-[0.3em] text-blue-500 mb-6 flex items-center gap-2 border-b border-white/5 pb-4">
              <i className="fas fa-vial"></i>
              Technical Lab Results
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="text-[9px] uppercase tracking-widest text-slate-600 font-bold mb-1 block">Melodic Phrasing & Vocal Chain</label>
                <div className="text-[10px] font-mono text-blue-300 bg-black/60 p-4 rounded-lg border border-white/5 leading-relaxed shadow-inner">
                  {profile.vocalChain || "AWAITING RESEARCH..."}
                </div>
              </div>

              <div>
                <label className="text-[9px] uppercase tracking-widest text-slate-600 font-bold mb-1 block">Air & Transient Topology</label>
                <div className="text-[10px] font-mono text-amber-400 bg-black/60 p-4 rounded-lg border border-white/5 leading-relaxed shadow-inner">
                  {profile.components.highEnd || "AWAITING RESEARCH..."}
                </div>
              </div>

              <div>
                <label className="text-[9px] uppercase tracking-widest text-slate-600 font-bold mb-1 block">Sub-Fundamental & Harmonics</label>
                <div className="text-[10px] font-mono text-emerald-400 bg-black/60 p-4 rounded-lg border border-white/5 leading-relaxed shadow-inner">
                  {profile.components.bass || "AWAITING RESEARCH..."}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <div className="text-[9px] text-slate-600 font-bold uppercase mb-1">Harmonic Key</div>
                  <div className="text-sm font-mono text-white">{profile.key} <span className="text-[9px] text-blue-500/50">({profile.camelot})</span></div>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <div className="text-[9px] text-slate-600 font-bold uppercase mb-1">Clock (BPM)</div>
                  <div className="text-sm font-mono text-blue-500">{profile.bpm}</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Right Column: Score & Generator */}
        <section className="lg:col-span-8 space-y-6">
          <div className="glass rounded-2xl p-8 border-white/5 bg-black/40 shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold font-heading uppercase tracking-tighter flex items-center gap-3">
                <i className="fas fa-music text-blue-500 text-sm"></i>
                High-Resolution Melodic Score
              </h2>
              {!userInput && (
                <span className="text-[9px] bg-blue-500/20 text-blue-400 py-1 px-3 rounded-full font-bold uppercase tracking-widest animate-pulse">Melodic Deepthink Active</span>
              )}
            </div>

            <textarea 
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              className="w-full h-48 bg-black/80 border border-white/10 rounded-xl p-6 text-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-500/30 transition-all font-mono text-sm leading-relaxed mb-4 shadow-inner"
              placeholder="Paste existing lyrics for melodic contour audit... or leave empty for Deeptink generation."
            />

            <button 
              onClick={handleGenerate}
              disabled={isGenerating}
              className={`w-full py-5 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-3 uppercase tracking-[0.3em] ${
                isGenerating 
                ? 'bg-slate-900 text-slate-700 cursor-not-allowed' 
                : 'bg-white text-black hover:bg-blue-50 shadow-xl'
              }`}
            >
              {isGenerating ? (
                <><i className="fas fa-wave-square animate-pulse"></i> LOCKING MELODIC CONTOUR...</>
              ) : (
                <>{userInput ? 'AUDIT MELODY & ANNOTATE' : 'GENERATE MASTER MELODIC SCORE'}</>
              )}
            </button>
          </div>

          {/* Results Area */}
          {result && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              {/* Layered Style Prompt */}
              <div className="glass rounded-xl p-6 border-l-4 border-l-blue-500 bg-blue-500/5 shadow-2xl">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest flex items-center gap-2">
                    <i className="fas fa-layer-group"></i> MELODIC DNA TAGS
                  </span>
                  <button onClick={() => copyToClipboard(result.soundStyle)} className="text-slate-500 hover:text-white transition-colors bg-white/5 p-2 rounded-lg">
                    <i className="fas fa-copy text-xs mr-2"></i> COPY TAGS
                  </button>
                </div>
                <div className="text-[13px] text-white font-mono leading-relaxed bg-black/80 p-6 rounded-lg border border-white/5 select-all shadow-inner">
                  {result.soundStyle}
                </div>
              </div>

              {/* Rhythmic & Melodic Annotated Score */}
              <div className="glass rounded-2xl p-8 border-t-2 border-blue-500/20 shadow-2xl bg-black/40 border-white/5">
                <div className="flex justify-between items-center mb-8 border-b border-white/5 pb-4">
                  <h3 className="text-xs font-bold text-blue-400 uppercase tracking-[0.4em]">Melodic Phrasing Score</h3>
                  <button onClick={() => copyToClipboard(result.structure + "\n\n" + result.lyrics)} className="text-[10px] font-bold text-blue-500 bg-blue-500/5 px-6 py-3 rounded-lg border border-blue-500/20 hover:bg-blue-500/10 transition-all uppercase tracking-widest">
                    <i className="fas fa-copy mr-2"></i> COPY ENTIRE SCORE
                  </button>
                </div>
                <div className="bg-black/80 rounded-xl p-10 border border-white/5 max-h-[600px] overflow-y-auto font-mono text-sm leading-loose scrollbar-thin shadow-inner">
                  <div className="text-[11px] text-blue-400 font-bold uppercase tracking-widest mb-10 pb-6 border-b border-white/5 italic text-center leading-relaxed">
                    EVOLUTION TOPOLOGY: {result.structure}
                  </div>
                  <div className="space-y-5">
                    {result.lyrics.split('\n').map((line, i) => {
                      const isInstruction = line.trim().startsWith('[') && line.trim().endsWith(']');
                      return (
                        <div key={i} className={`${isInstruction ? "text-blue-500 font-bold text-[10px] mt-8 mb-2 uppercase tracking-widest bg-blue-500/10 py-2 px-4 rounded inline-block border border-blue-500/20" : "text-slate-300 font-normal"}`}>
                          {line.split(/(\[.*?\])/).map((part, pi) => {
                            if (part.startsWith('[') && part.endsWith(']')) {
                              // Distinct color for melodic instructions vs physiological ones if possible, 
                              // but sticking to emerald for consistency with current UI.
                              return <span key={pi} className="text-emerald-500/90 font-bold mx-1 text-[10px] italic">{part}</span>;
                            }
                            return part;
                          })}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Negative DNA Filter */}
              <div className="glass rounded-xl p-4 border border-red-500/10 bg-red-500/5">
                <div className="flex justify-between items-center mb-2">
                   <span className="text-[9px] font-bold text-red-400 uppercase tracking-widest">Negative DNA Filter</span>
                   <button onClick={() => copyToClipboard(result.negativePrompt)} className="text-[10px] text-slate-500 hover:text-white uppercase font-bold">Copy</button>
                </div>
                <p className="text-[10px] text-slate-500 font-mono leading-relaxed italic">{result.negativePrompt}</p>
              </div>
            </div>
          )}

          {error && (
            <div className="bg-red-950/20 border border-red-500/20 rounded-xl p-6 text-red-500 flex items-center gap-4 text-xs font-mono uppercase tracking-widest">
              <i className="fas fa-exclamation-triangle"></i>
              AUDIT ERROR: {error}
            </div>
          )}
        </section>
      </main>
      
      {/* Visualizer Decoration */}
      <div className="fixed bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-blue-500/20 to-transparent flex items-end overflow-hidden opacity-50">
        {[...Array(40)].map((_, i) => (
          <div 
            key={i} 
            className="flex-1 bg-blue-500/40" 
            style={{ 
              height: `${Math.random() * 100}%`,
              transition: 'height 0.2s ease-in-out'
            }}
          ></div>
        ))}
      </div>
    </div>
  );
}
