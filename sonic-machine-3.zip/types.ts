
export interface SonicComponent {
  rhythm: string;
  bass: string;
  midRange: string;
  highEnd: string;
  atmosphere: string;
}

export interface SonicProfile {
  name: string;
  description: string;
  components: SonicComponent;
  structureTemplate: string;
  negativePrompt: string;
  bpm: string;
  swing: string;
  key: string;
  camelot: string;
  vocalChain: string;      // Specific recording chain (e.g., SM7B -> Neve 1073)
  instrumentArray: string; // List of physical hardware used
}

export interface GeneratedPrompt {
  soundStyle: string;
  negativePrompt: string;
  lyrics: string;
  structure: string;
  groundingUrls?: string[];
}
