
import { GoogleGenAI, Type } from "@google/genai";
import { SonicProfile, GeneratedPrompt } from "./types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

/**
 * Performs a Lossless Master Grade Forensic Audit.
 * Reconstructs the absolute peak-fidelity technical DNA including Melodic Contour and Interval Logic.
 */
export const searchAndAnalyzeSonicProfile = async (query: string, customSetting?: string): Promise<SonicProfile & { sources: any[] }> => {
  const ai = getAI();
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `
    PERFORM LOSSLESS MASTER GRADE FORENSIC AUDIT FOR: "${query}".
    
    RESEARCH MISSION:
    You are an Elite Mastering Engineer and Musicologist analyzing the absolute master tapes. Reconstruct the technical DNA with zero loss in detail.
    
    CORE AUDIT MODULES (HIGH-RESOLUTION MANDATE):
    1. HARMONIC & TEMPORAL TOPOLOGY:
       - Verify exact BPM (including micro-drifts), Time Signature (swing-percentile precision), and Key (Camelot Wheel + frequency offset, e.g., A=440Hz).
       - Identify the "Harmonic Saturation Profile": 2nd-order (Tube), 3rd-order (Tape/Transformer), and specific hardware distortion.
    
    2. MELODIC DNA & INTERVAL LOGIC:
       - Analyze characteristic pitch movements: [Large interval leaps], [Stepwise motion], [Pentatonic bias], [Chromatic tension], [Blue notes].
       - Identify "Melodic Phrasing": [Anticipated beats], [Lagging behind the snare], [Syncopated pitch shifts].
       - This will be used to steer Suno's internal melodic engine.

    3. PHYSIOLOGICAL PERFORMANCE MAPPING:
       - Deep-dive into the performer's vocal mechanics: [Breathy air-flow], [Nasal/Sinus focus], [Deep chest resonance], [Falsetto/Head transitions], [Vocal fry/Glottal grit].
       - Map these to the 'vocalChain' with hardware-to-physiology translation: Mic model, Preamp, and specific EQ points.
    
    4. SIGNAL PATH PHYSICS & TRANSIENTS:
       - Identify the 'Transient Profile': Sharp/Aggressive vs. Soft/Analog-clamped.
       - Identify 'Phase Correlation' and 'Space Topology' (Reverb models/decay).
    
    5. ARCHITECTURAL MASTER PLAN:
       - Precise structural build: [Start dry mono] -> [Full 24-bit studio stereo expansion at climax].
    
    STRICT OUTPUT RULES:
    - BANNED: Subjective adjectives ("Amazing", "Great").
    - MANDATORY: Engineering and Musicology terminology.
    
    ${customSetting ? `SYSTEM OVERRIDE: ${customSetting}` : ""}
    `,
    config: {
      tools: [{ googleSearch: {} }],
      thinkingConfig: { thinkingBudget: 32768 },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          description: { type: Type.STRING },
          components: {
            type: Type.OBJECT,
            properties: {
              rhythm: { type: Type.STRING, description: "Transient envelope + precise quantization + hardware core." },
              bass: { type: Type.STRING, description: "Sub-fundamental frequency + harmonic order + hardware chain." },
              midRange: { type: Type.STRING, description: "Oscillator topology + cabinet/mic models + phase width." },
              highEnd: { type: Type.STRING, description: "Vocal air/physiology + melodic interval bias + bit-depth." },
              atmosphere: { type: Type.STRING, description: "Reverb algorithms + pre-delay constants + spatial physics." }
            },
            required: ["rhythm", "bass", "midRange", "highEnd", "atmosphere"]
          },
          structureTemplate: { type: Type.STRING },
          negativePrompt: { type: Type.STRING },
          bpm: { type: Type.STRING },
          swing: { type: Type.STRING },
          key: { type: Type.STRING },
          camelot: { type: Type.STRING },
          vocalChain: { type: Type.STRING, description: "Hardware chain + Physiological focus + Melodic Phrasing DNA." },
          instrumentArray: { type: Type.STRING }
        },
        required: ["name", "description", "components", "structureTemplate", "negativePrompt", "bpm", "swing", "key", "camelot", "vocalChain", "instrumentArray"]
      }
    }
  });

  const profile = JSON.parse(response.text || '{}');
  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  
  return { ...profile, sources };
};

/**
 * Compiles a Layered High-Fidelity Binary Prompt for Suno v5.
 * Uses Deepthinking to perform a 'Melodic Contour & Syllabic Stress Audit'.
 */
export const generateSunoPrompt = async (profile: SonicProfile, lyricsInput: string, customSetting?: string): Promise<GeneratedPrompt> => {
  const ai = getAI();
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `
    USE DEEP REASONING TO COMPILE A MASTER-GRADE MELODIC & RHYTHMIC SCORE FOR SUNO V5.
    
    AUDIT PACKET (LOSSLESS):
    - Harmonic Key/Camelot: ${profile.key} / ${profile.camelot}
    - Melodic DNA: ${profile.vocalChain}
    - Hardware DNA: ${profile.instrumentArray}
    - Space Topology: ${profile.components.atmosphere}
    
    COMPILER ARCHITECTURE:
    1. MASTER CHAIN STYLE PROMPT:
       - Foundation Layer: [BPM] [Key] [Time Signature] [Lossless quality].
       - Engine Layer: [Hardware-specific tags].
       - Melodic Layer: [Interval bias tags: e.g., Large leaps, Stepwise, Arpeggiated melody, Pentatonic contour].
       - Performance Layer: [Vocal markers: Breathy, Nasal, Chest resonance, Falsetto lift, Vocal fry grit].

    2. MELODIC CONTOUR & SYLLABIC SCORE:
       - Perform a "Melodic Trajectory Audit": determine where the pitch should lift or drop based on the research DNA.
       - If lyrics provided: Rewrite/Annotate to lock both the syllable stress AND the melodic contour.
       - Embed Melodic & Technical Performance tags directly into the text using []:
         * Melodic: [melodic ascent], [vibrato tail], [descending minor third], [staccato pitch jumps], [sustained high note].
         * Technical: [heavy breathy intake], [glottal fry grit], [nasal resonance], [resonant chest power].

    3. NEGATIVE DNA FILTER:
       - Purge "AI-typical" flat melodic contours and generic phrasing.
    
    INPUT SOURCE:
    ${lyricsInput || "GENERATE NEW SCORE FROM SCRATCH - REPLICATE MELODIC & SYLLABIC DNA OF TARGET"}
    `,
    config: {
      thinkingConfig: { thinkingBudget: 32768 },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          soundStyle: { type: Type.STRING, description: "Layered [Bracketed Tags] including Melodic Contour directives." },
          negativePrompt: { type: Type.STRING },
          lyrics: { type: Type.STRING, description: "High-resolution melodic score with technical & pitch markers." },
          structure: { type: Type.STRING }
        },
        required: ["soundStyle", "negativePrompt", "lyrics", "structure"]
      }
    }
  });

  return JSON.parse(response.text || '{}') as GeneratedPrompt;
};
