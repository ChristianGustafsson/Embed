
import { SonicProfile } from './types';

export const DEFAULT_PROFILE: SonicProfile = {
  name: "Arena Forensic Template",
  description: "Stadium-scale engineering for high-energy electronic and pop.",
  components: {
    rhythm: "909 core, side-chained white noise, heavy bus compression, 4/4 kick transient.",
    bass: "Moog Sub 37 sawtooth, side-chain pumping (1/8 note), high-pass filter at 30Hz.",
    midRange: "Hypersaw layers (7 oscillators), detuned unison, acoustic guitar DI blend.",
    highEnd: "White noise swells, 15kHz excitation, stereo widened hi-hats.",
    atmosphere: "Stadium acoustics, 5.5s Hall reverb decay, 200% stereo expansion, pre-delay 40ms."
  },
  structureTemplate: "[0:00 Ambient Intro] -> [0:30 Build-up] -> [1:00 Stadium Drop] -> [1:45 Verse]",
  negativePrompt: "Jazz, soul, lo-fi, small room, dry mix, acoustic drums, generic pop, mumble, background music.",
  bpm: "128",
  swing: "0%",
  key: "G Minor",
  camelot: "8A",
  vocalChain: "Neumann U87, 1176 fast attack, massive stereo delay, high-shelf boost.",
  instrumentArray: "Roland TR-909, Sylenth1 Hypersaws, Moog Sub 37, Acoustic Guitar, Stadium Reverb Hardware."
};

export const SAMPLE_LYRICS_INPUT = `[Stadium Intro]
[Build-up]
Feel the static in the air
Electric current everywhere
[Drop]
(Side-chained synths only)
[Verse]
Silicon soul in a digital cage
Breaking out of the arena stage.`;
